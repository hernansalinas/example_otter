OK_FORMAT = True

test = {   'name': 'qt',
    'points': 0,
    'suites': [   {   'cases': [   {   'code': '>>> assert isinstance(NombreApellidos, str)\n'
                                               '>>> assert isinstance(NumeroCarnet, str)\n'
                                               '>>> assert isinstance(Email, str)\n'
                                               '>>> assert len(NombreApellidos) > 3\n'
                                               '>>> assert len(NumeroCarnet) > 3\n'
                                               '>>> assert len(Email) > 3\n',
                                       'hidden': False,
                                       'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
